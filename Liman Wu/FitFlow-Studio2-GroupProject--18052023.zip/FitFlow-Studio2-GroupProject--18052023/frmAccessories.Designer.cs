﻿namespace FitFlow_Studio2_GroupProject
{
    partial class frmAccessories
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelItem1 = new System.Windows.Forms.Panel();
            this.lblItem1 = new System.Windows.Forms.Label();
            this.panelItem4 = new System.Windows.Forms.Panel();
            this.lblItem4 = new System.Windows.Forms.Label();
            this.panelItem2 = new System.Windows.Forms.Panel();
            this.lblItem2 = new System.Windows.Forms.Label();
            this.panelItem3 = new System.Windows.Forms.Panel();
            this.lblItem3 = new System.Windows.Forms.Label();
            this.pictureBoxItem1 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBoxItem4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBoxItem2 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBoxItem3 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panelItem1.SuspendLayout();
            this.panelItem4.SuspendLayout();
            this.panelItem2.SuspendLayout();
            this.panelItem3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // panelItem1
            // 
            this.panelItem1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panelItem1.Controls.Add(this.pictureBoxItem1);
            this.panelItem1.Controls.Add(this.pictureBox1);
            this.panelItem1.Controls.Add(this.lblItem1);
            this.panelItem1.Location = new System.Drawing.Point(48, 77);
            this.panelItem1.Name = "panelItem1";
            this.panelItem1.Size = new System.Drawing.Size(302, 183);
            this.panelItem1.TabIndex = 3;
            // 
            // lblItem1
            // 
            this.lblItem1.AutoSize = true;
            this.lblItem1.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem1.ForeColor = System.Drawing.Color.White;
            this.lblItem1.Location = new System.Drawing.Point(167, 11);
            this.lblItem1.Name = "lblItem1";
            this.lblItem1.Size = new System.Drawing.Size(118, 21);
            this.lblItem1.TabIndex = 0;
            this.lblItem1.Text = "Sports Clothing";
            // 
            // panelItem4
            // 
            this.panelItem4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panelItem4.Controls.Add(this.pictureBoxItem4);
            this.panelItem4.Controls.Add(this.pictureBox3);
            this.panelItem4.Controls.Add(this.lblItem4);
            this.panelItem4.Location = new System.Drawing.Point(384, 282);
            this.panelItem4.Name = "panelItem4";
            this.panelItem4.Size = new System.Drawing.Size(302, 183);
            this.panelItem4.TabIndex = 4;
            // 
            // lblItem4
            // 
            this.lblItem4.AutoSize = true;
            this.lblItem4.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem4.ForeColor = System.Drawing.Color.White;
            this.lblItem4.Location = new System.Drawing.Point(167, 11);
            this.lblItem4.Name = "lblItem4";
            this.lblItem4.Size = new System.Drawing.Size(118, 21);
            this.lblItem4.TabIndex = 0;
            this.lblItem4.Text = "Sports Clothing";
            // 
            // panelItem2
            // 
            this.panelItem2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panelItem2.Controls.Add(this.pictureBoxItem2);
            this.panelItem2.Controls.Add(this.pictureBox5);
            this.panelItem2.Controls.Add(this.lblItem2);
            this.panelItem2.Location = new System.Drawing.Point(384, 77);
            this.panelItem2.Name = "panelItem2";
            this.panelItem2.Size = new System.Drawing.Size(302, 183);
            this.panelItem2.TabIndex = 5;
            // 
            // lblItem2
            // 
            this.lblItem2.AutoSize = true;
            this.lblItem2.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem2.ForeColor = System.Drawing.Color.White;
            this.lblItem2.Location = new System.Drawing.Point(167, 11);
            this.lblItem2.Name = "lblItem2";
            this.lblItem2.Size = new System.Drawing.Size(118, 21);
            this.lblItem2.TabIndex = 0;
            this.lblItem2.Text = "Sports Clothing";
            // 
            // panelItem3
            // 
            this.panelItem3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panelItem3.Controls.Add(this.pictureBoxItem3);
            this.panelItem3.Controls.Add(this.pictureBox7);
            this.panelItem3.Controls.Add(this.lblItem3);
            this.panelItem3.Location = new System.Drawing.Point(48, 282);
            this.panelItem3.Name = "panelItem3";
            this.panelItem3.Size = new System.Drawing.Size(302, 183);
            this.panelItem3.TabIndex = 6;
            // 
            // lblItem3
            // 
            this.lblItem3.AutoSize = true;
            this.lblItem3.Font = new System.Drawing.Font("Nirmala UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItem3.ForeColor = System.Drawing.Color.White;
            this.lblItem3.Location = new System.Drawing.Point(167, 11);
            this.lblItem3.Name = "lblItem3";
            this.lblItem3.Size = new System.Drawing.Size(118, 21);
            this.lblItem3.TabIndex = 0;
            this.lblItem3.Text = "Sports Clothing";
            // 
            // pictureBoxItem1
            // 
            this.pictureBoxItem1.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.Accessories1;
            this.pictureBoxItem1.Location = new System.Drawing.Point(12, 14);
            this.pictureBoxItem1.Name = "pictureBoxItem1";
            this.pictureBoxItem1.Size = new System.Drawing.Size(149, 153);
            this.pictureBoxItem1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxItem1.TabIndex = 1;
            this.pictureBoxItem1.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(12, 11);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(149, 146);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBoxItem4
            // 
            this.pictureBoxItem4.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.MenWear;
            this.pictureBoxItem4.Location = new System.Drawing.Point(12, 14);
            this.pictureBoxItem4.Name = "pictureBoxItem4";
            this.pictureBoxItem4.Size = new System.Drawing.Size(149, 153);
            this.pictureBoxItem4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxItem4.TabIndex = 1;
            this.pictureBoxItem4.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Location = new System.Drawing.Point(12, 11);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(149, 146);
            this.pictureBox3.TabIndex = 1;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBoxItem2
            // 
            this.pictureBoxItem2.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.Accessories1;
            this.pictureBoxItem2.Location = new System.Drawing.Point(12, 14);
            this.pictureBoxItem2.Name = "pictureBoxItem2";
            this.pictureBoxItem2.Size = new System.Drawing.Size(149, 153);
            this.pictureBoxItem2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxItem2.TabIndex = 1;
            this.pictureBoxItem2.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Location = new System.Drawing.Point(12, 11);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(149, 146);
            this.pictureBox5.TabIndex = 1;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBoxItem3
            // 
            this.pictureBoxItem3.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.Accessories1;
            this.pictureBoxItem3.Location = new System.Drawing.Point(12, 14);
            this.pictureBoxItem3.Name = "pictureBoxItem3";
            this.pictureBoxItem3.Size = new System.Drawing.Size(149, 153);
            this.pictureBoxItem3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxItem3.TabIndex = 1;
            this.pictureBoxItem3.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Location = new System.Drawing.Point(12, 11);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(149, 146);
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.pictureBox2.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.cartCircle_fotor_bg_remover_20230518151519;
            this.pictureBox2.Location = new System.Drawing.Point(607, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(79, 67);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 20;
            this.pictureBox2.TabStop = false;
            // 
            // frmAccessories
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(733, 477);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.panelItem1);
            this.Controls.Add(this.panelItem4);
            this.Controls.Add(this.panelItem2);
            this.Controls.Add(this.panelItem3);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmAccessories";
            this.Text = "frmAccessories";
            this.panelItem1.ResumeLayout(false);
            this.panelItem1.PerformLayout();
            this.panelItem4.ResumeLayout(false);
            this.panelItem4.PerformLayout();
            this.panelItem2.ResumeLayout(false);
            this.panelItem2.PerformLayout();
            this.panelItem3.ResumeLayout(false);
            this.panelItem3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxItem3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelItem1;
        private System.Windows.Forms.PictureBox pictureBoxItem1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lblItem1;
        private System.Windows.Forms.Panel panelItem4;
        private System.Windows.Forms.PictureBox pictureBoxItem4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label lblItem4;
        private System.Windows.Forms.Panel panelItem2;
        private System.Windows.Forms.PictureBox pictureBoxItem2;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblItem2;
        private System.Windows.Forms.Panel panelItem3;
        private System.Windows.Forms.PictureBox pictureBoxItem3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label lblItem3;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}