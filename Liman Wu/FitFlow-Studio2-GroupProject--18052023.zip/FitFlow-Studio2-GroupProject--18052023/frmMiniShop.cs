﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FitFlow_Studio2_GroupProject
{
    public partial class frmMiniShop : Form
    {
        //passing labelTitle around forms
        public static frmMiniShop instance;
        public frmMiniShop()
        {
            InitializeComponent();
            //passing labelTitle around forms
            instance = this;
        }

        private void pictureBoxMenWear_Click(object sender, EventArgs e)
        {
            //load Dashboard page
            //passing labelTitle around forms
            FormMain.instance.lbl.Text = "Men Wear";
            FormMain.instance.panel.Controls.Clear();
            frmMenWear formDashboard_Vr6 = new frmMenWear()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            FormMain.instance.panel.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void pictureBoxWomenWear_Click(object sender, EventArgs e)
        {
            //load Dashboard page
            //passing labelTitle around forms
            FormMain.instance.lbl.Text = "Women Wear";
            FormMain.instance.panel.Controls.Clear();
            frmWomenWear formDashboard_Vr6 = new frmWomenWear()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            FormMain.instance.panel.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            //load Dashboard page
            //passing labelTitle around forms
            FormMain.instance.lbl.Text = "Accessories";
            FormMain.instance.panel.Controls.Clear();
            frmAccessories formDashboard_Vr6 = new frmAccessories()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            FormMain.instance.panel.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
