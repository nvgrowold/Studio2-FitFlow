﻿namespace FitFlow_Studio2_GroupProject
{
    partial class frmMiniShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBoxWomenWear = new System.Windows.Forms.PictureBox();
            this.pictureBoxMenWear = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWomenWear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenWear)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.pictureBox1.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.cartCircle_fotor_bg_remover_20230518151519;
            this.pictureBox1.Location = new System.Drawing.Point(583, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(76, 81);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 19;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.Accessories1;
            this.pictureBox2.Location = new System.Drawing.Point(501, 118);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(158, 166);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 18;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // pictureBoxWomenWear
            // 
            this.pictureBoxWomenWear.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.WomenWear;
            this.pictureBoxWomenWear.Location = new System.Drawing.Point(297, 118);
            this.pictureBoxWomenWear.Name = "pictureBoxWomenWear";
            this.pictureBoxWomenWear.Size = new System.Drawing.Size(158, 166);
            this.pictureBoxWomenWear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxWomenWear.TabIndex = 16;
            this.pictureBoxWomenWear.TabStop = false;
            this.pictureBoxWomenWear.Click += new System.EventHandler(this.pictureBoxWomenWear_Click);
            // 
            // pictureBoxMenWear
            // 
            this.pictureBoxMenWear.Image = global::FitFlow_Studio2_GroupProject.Properties.Resources.MenWear;
            this.pictureBoxMenWear.Location = new System.Drawing.Point(95, 118);
            this.pictureBoxMenWear.Name = "pictureBoxMenWear";
            this.pictureBoxMenWear.Size = new System.Drawing.Size(158, 166);
            this.pictureBoxMenWear.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxMenWear.TabIndex = 14;
            this.pictureBoxMenWear.TabStop = false;
            this.pictureBoxMenWear.Click += new System.EventHandler(this.pictureBoxMenWear_Click);
            // 
            // frmMiniShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(733, 477);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBoxWomenWear);
            this.Controls.Add(this.pictureBoxMenWear);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "frmMiniShop";
            this.Text = "frmMiniShop";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxWomenWear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxMenWear)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.PictureBox pictureBoxMenWear;
        private System.Windows.Forms.PictureBox pictureBoxWomenWear;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}