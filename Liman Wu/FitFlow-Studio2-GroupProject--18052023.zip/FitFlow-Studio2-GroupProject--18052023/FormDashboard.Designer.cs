﻿namespace FitFlow_Studio2_GroupProject
{
    partial class FormDashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormDashboard));
            this.lblWater = new System.Windows.Forms.Label();
            this.pnlCal = new System.Windows.Forms.Panel();
            this.lblCal = new System.Windows.Forms.Label();
            this.circularProgressBarCal = new CircularProgressBar.CircularProgressBar();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.lblLogSteps = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLogFood = new System.Windows.Forms.Label();
            this.pnlWater = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.circularProgressBarWater = new CircularProgressBar.CircularProgressBar();
            this.pnlSteps = new System.Windows.Forms.Panel();
            this.lblSteps = new System.Windows.Forms.Label();
            this.circularProgressBarSteps = new CircularProgressBar.CircularProgressBar();
            this.pnlCal.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.pnlWater.SuspendLayout();
            this.pnlSteps.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblWater
            // 
            this.lblWater.AutoSize = true;
            this.lblWater.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWater.ForeColor = System.Drawing.Color.White;
            this.lblWater.Location = new System.Drawing.Point(-58, 91);
            this.lblWater.Name = "lblWater";
            this.lblWater.Size = new System.Drawing.Size(62, 25);
            this.lblWater.TabIndex = 11;
            this.lblWater.Text = "Water";
            // 
            // pnlCal
            // 
            this.pnlCal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlCal.Controls.Add(this.lblCal);
            this.pnlCal.Controls.Add(this.circularProgressBarCal);
            this.pnlCal.Location = new System.Drawing.Point(48, 36);
            this.pnlCal.Name = "pnlCal";
            this.pnlCal.Size = new System.Drawing.Size(164, 172);
            this.pnlCal.TabIndex = 12;
            // 
            // lblCal
            // 
            this.lblCal.AutoSize = true;
            this.lblCal.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCal.ForeColor = System.Drawing.Color.White;
            this.lblCal.Location = new System.Drawing.Point(42, 140);
            this.lblCal.Name = "lblCal";
            this.lblCal.Size = new System.Drawing.Size(80, 25);
            this.lblCal.TabIndex = 1;
            this.lblCal.Text = "Calories";
            // 
            // circularProgressBarCal
            // 
            this.circularProgressBarCal.AnimationFunction = ((WinFormAnimation.AnimationFunctions.Function)(resources.GetObject("circularProgressBarCal.AnimationFunction")));
            this.circularProgressBarCal.AnimationSpeed = 500;
            this.circularProgressBarCal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarCal.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circularProgressBarCal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(249)))));
            this.circularProgressBarCal.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarCal.InnerMargin = 2;
            this.circularProgressBarCal.InnerWidth = -1;
            this.circularProgressBarCal.Location = new System.Drawing.Point(16, 7);
            this.circularProgressBarCal.MarqueeAnimationSpeed = 2000;
            this.circularProgressBarCal.Name = "circularProgressBarCal";
            this.circularProgressBarCal.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.circularProgressBarCal.OuterMargin = -25;
            this.circularProgressBarCal.OuterWidth = 26;
            this.circularProgressBarCal.ProgressColor = System.Drawing.Color.Plum;
            this.circularProgressBarCal.ProgressWidth = 7;
            this.circularProgressBarCal.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circularProgressBarCal.Size = new System.Drawing.Size(130, 130);
            this.circularProgressBarCal.StartAngle = 270;
            this.circularProgressBarCal.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarCal.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBarCal.SubscriptText = "";
            this.circularProgressBarCal.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarCal.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBarCal.SuperscriptText = "";
            this.circularProgressBarCal.TabIndex = 0;
            this.circularProgressBarCal.Text = "1,250";
            this.circularProgressBarCal.TextMargin = new System.Windows.Forms.Padding(3, 5, 0, 0);
            this.circularProgressBarCal.Value = 68;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel4.Controls.Add(this.label5);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Location = new System.Drawing.Point(490, 254);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(233, 206);
            this.panel4.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(42, 140);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(80, 25);
            this.label5.TabIndex = 1;
            this.label5.Text = "Calories";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(146)))), ((int)(((byte)(249)))));
            this.label6.Location = new System.Drawing.Point(64, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(105, 24);
            this.label6.TabIndex = 2;
            this.label6.Text = "Log Water";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.lblLogSteps);
            this.panel3.Location = new System.Drawing.Point(251, 254);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(233, 206);
            this.panel3.TabIndex = 17;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(42, 140);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 25);
            this.label3.TabIndex = 1;
            this.label3.Text = "Calories";
            // 
            // lblLogSteps
            // 
            this.lblLogSteps.AutoSize = true;
            this.lblLogSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogSteps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(146)))), ((int)(((byte)(249)))));
            this.lblLogSteps.Location = new System.Drawing.Point(73, 3);
            this.lblLogSteps.Name = "lblLogSteps";
            this.lblLogSteps.Size = new System.Drawing.Size(103, 24);
            this.lblLogSteps.TabIndex = 2;
            this.lblLogSteps.Text = "Log Steps";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.lblLogFood);
            this.panel1.Location = new System.Drawing.Point(12, 254);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 206);
            this.panel1.TabIndex = 15;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(42, 140);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(80, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Calories";
            // 
            // lblLogFood
            // 
            this.lblLogFood.AutoSize = true;
            this.lblLogFood.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLogFood.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(146)))), ((int)(((byte)(249)))));
            this.lblLogFood.Location = new System.Drawing.Point(58, 7);
            this.lblLogFood.Name = "lblLogFood";
            this.lblLogFood.Size = new System.Drawing.Size(100, 24);
            this.lblLogFood.TabIndex = 2;
            this.lblLogFood.Text = "Log Food";
            // 
            // pnlWater
            // 
            this.pnlWater.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlWater.Controls.Add(this.label1);
            this.pnlWater.Controls.Add(this.circularProgressBarWater);
            this.pnlWater.Location = new System.Drawing.Point(520, 36);
            this.pnlWater.Name = "pnlWater";
            this.pnlWater.Size = new System.Drawing.Size(164, 172);
            this.pnlWater.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(52, 140);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "Water";
            // 
            // circularProgressBarWater
            // 
            this.circularProgressBarWater.AnimationFunction = ((WinFormAnimation.AnimationFunctions.Function)(resources.GetObject("circularProgressBarWater.AnimationFunction")));
            this.circularProgressBarWater.AnimationSpeed = 500;
            this.circularProgressBarWater.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarWater.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circularProgressBarWater.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(249)))));
            this.circularProgressBarWater.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarWater.InnerMargin = 2;
            this.circularProgressBarWater.InnerWidth = -1;
            this.circularProgressBarWater.Location = new System.Drawing.Point(16, 7);
            this.circularProgressBarWater.MarqueeAnimationSpeed = 2000;
            this.circularProgressBarWater.Name = "circularProgressBarWater";
            this.circularProgressBarWater.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.circularProgressBarWater.OuterMargin = -25;
            this.circularProgressBarWater.OuterWidth = 26;
            this.circularProgressBarWater.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(249)))));
            this.circularProgressBarWater.ProgressWidth = 7;
            this.circularProgressBarWater.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circularProgressBarWater.Size = new System.Drawing.Size(130, 130);
            this.circularProgressBarWater.StartAngle = 270;
            this.circularProgressBarWater.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarWater.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBarWater.SubscriptText = "";
            this.circularProgressBarWater.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarWater.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBarWater.SuperscriptText = "";
            this.circularProgressBarWater.TabIndex = 0;
            this.circularProgressBarWater.Text = "2L";
            this.circularProgressBarWater.TextMargin = new System.Windows.Forms.Padding(3, 5, 0, 0);
            this.circularProgressBarWater.Value = 68;
            // 
            // pnlSteps
            // 
            this.pnlSteps.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.pnlSteps.Controls.Add(this.lblSteps);
            this.pnlSteps.Controls.Add(this.circularProgressBarSteps);
            this.pnlSteps.Location = new System.Drawing.Point(278, 36);
            this.pnlSteps.Name = "pnlSteps";
            this.pnlSteps.Size = new System.Drawing.Size(164, 172);
            this.pnlSteps.TabIndex = 14;
            // 
            // lblSteps
            // 
            this.lblSteps.AutoSize = true;
            this.lblSteps.Font = new System.Drawing.Font("Nirmala UI", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSteps.ForeColor = System.Drawing.Color.White;
            this.lblSteps.Location = new System.Drawing.Point(56, 140);
            this.lblSteps.Name = "lblSteps";
            this.lblSteps.Size = new System.Drawing.Size(56, 25);
            this.lblSteps.TabIndex = 1;
            this.lblSteps.Text = "Steps";
            // 
            // circularProgressBarSteps
            // 
            this.circularProgressBarSteps.AnimationFunction = ((WinFormAnimation.AnimationFunctions.Function)(resources.GetObject("circularProgressBarSteps.AnimationFunction")));
            this.circularProgressBarSteps.AnimationSpeed = 500;
            this.circularProgressBarSteps.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarSteps.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.circularProgressBarSteps.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(162)))), ((int)(((byte)(249)))));
            this.circularProgressBarSteps.InnerColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(42)))), ((int)(((byte)(64)))));
            this.circularProgressBarSteps.InnerMargin = 2;
            this.circularProgressBarSteps.InnerWidth = -1;
            this.circularProgressBarSteps.Location = new System.Drawing.Point(16, 7);
            this.circularProgressBarSteps.MarqueeAnimationSpeed = 2000;
            this.circularProgressBarSteps.Name = "circularProgressBarSteps";
            this.circularProgressBarSteps.OuterColor = System.Drawing.Color.FromArgb(((int)(((byte)(24)))), ((int)(((byte)(30)))), ((int)(((byte)(54)))));
            this.circularProgressBarSteps.OuterMargin = -25;
            this.circularProgressBarSteps.OuterWidth = 26;
            this.circularProgressBarSteps.ProgressColor = System.Drawing.Color.Cyan;
            this.circularProgressBarSteps.ProgressWidth = 7;
            this.circularProgressBarSteps.SecondaryFont = new System.Drawing.Font("Microsoft Sans Serif", 36F);
            this.circularProgressBarSteps.Size = new System.Drawing.Size(130, 130);
            this.circularProgressBarSteps.StartAngle = 270;
            this.circularProgressBarSteps.SubscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarSteps.SubscriptMargin = new System.Windows.Forms.Padding(10, -35, 0, 0);
            this.circularProgressBarSteps.SubscriptText = "";
            this.circularProgressBarSteps.SuperscriptColor = System.Drawing.Color.FromArgb(((int)(((byte)(166)))), ((int)(((byte)(166)))), ((int)(((byte)(166)))));
            this.circularProgressBarSteps.SuperscriptMargin = new System.Windows.Forms.Padding(10, 35, 0, 0);
            this.circularProgressBarSteps.SuperscriptText = "";
            this.circularProgressBarSteps.TabIndex = 0;
            this.circularProgressBarSteps.Text = "15,000";
            this.circularProgressBarSteps.TextMargin = new System.Windows.Forms.Padding(3, 5, 0, 0);
            this.circularProgressBarSteps.Value = 68;
            // 
            // FormDashboard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(46)))), ((int)(((byte)(51)))), ((int)(((byte)(73)))));
            this.ClientSize = new System.Drawing.Size(733, 577);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pnlWater);
            this.Controls.Add(this.pnlSteps);
            this.Controls.Add(this.pnlCal);
            this.Controls.Add(this.lblWater);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "FormDashboard";
            this.Text = "FormUserProfile";
            this.pnlCal.ResumeLayout(false);
            this.pnlCal.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.pnlWater.ResumeLayout(false);
            this.pnlWater.PerformLayout();
            this.pnlSteps.ResumeLayout(false);
            this.pnlSteps.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblWater;
        private System.Windows.Forms.Panel pnlCal;
        private System.Windows.Forms.Label lblCal;
        private CircularProgressBar.CircularProgressBar circularProgressBarCal;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblLogSteps;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLogFood;
        private System.Windows.Forms.Panel pnlWater;
        private System.Windows.Forms.Label label1;
        private CircularProgressBar.CircularProgressBar circularProgressBarWater;
        private System.Windows.Forms.Panel pnlSteps;
        private System.Windows.Forms.Label lblSteps;
        private CircularProgressBar.CircularProgressBar circularProgressBarSteps;
    }
}