﻿
//Stuidio 2 Group Project -- FitFlow Fitness App

/*Requirements:
 * 
 * */



//Revision History
//================
//14.05.2023 LW Original version.


using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//make form round border
using System.Runtime.InteropServices;

namespace FitFlow_Studio2_GroupProject
{
    

    public partial class FormMain : Form
    {
        //make form round border
        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
         (
              int nLeftRect,
              int nTopRect,
              int nRightRect,
              int nBottomRect,
              int nWidthEllipse,
              int nHeightEllipse

          );
        //passing labelTitle around forms
        public static FormMain instance;
        public Label lbl;
        public Panel panel;

        public FormMain()
        {
            InitializeComponent();

            //passing labelTitle around forms
            instance = this;
            lbl = labelTitle;
            panel = this.panelFormLoader;

            //smoother the image loading
            DoubleBuffered = true;

            //make form round border
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 25, 25));

            //load Dashboard page
            labelTitle.Text = "Dashboard";
            this.panelFormLoader.Controls.Clear();
            FormDashboard formDashboard_Vr6 = new FormDashboard()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();


        }

        private void FormMain_Load(object sender, EventArgs e)
        {

        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnDashboard.Height;
            pnlNav.Top = btnDashboard.Top;
            pnlNav.Left = btnDashboard.Left;
            //change button color when clicked
            btnDashboard.BackColor = Color.FromArgb(46, 51, 73);

            //load Dashboard page
            labelTitle.Text = "Dashboard";
            this.panelFormLoader.Controls.Clear();
            FormDashboard formDashboard_Vr6 = new FormDashboard()
            {
                Dock = DockStyle.Fill, TopLevel = false, TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
            //copy this part of code and paste in InitializeComponent();
            
        }
        private void btnExercise_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnExercise.Height;
            pnlNav.Top = btnExercise.Top;
            pnlNav.Left = btnExercise.Left;
            //change button color when clicked
            btnExercise.BackColor = Color.FromArgb(46, 51, 73);

            //load Exercise page
            labelTitle.Text = "Exercise";
            this.panelFormLoader.Controls.Clear();
            frmExercise formDashboard_Vr6 = new frmExercise()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void btnJournal_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnJournal.Height;
            pnlNav.Top = btnJournal.Top;
            pnlNav.Left = btnJournal.Left;
            //change button color when clicked
            btnJournal.BackColor = Color.FromArgb(46, 51, 73);

            //load Journal page
            labelTitle.Text = "Journal";
            this.panelFormLoader.Controls.Clear();
            frmJournal formDashboard_Vr6 = new frmJournal()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void btnAppointment_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnAppointment.Height;
            pnlNav.Top = btnAppointment.Top;
            pnlNav.Left = btnAppointment.Left;
            //change button color when clicked
            btnAppointment.BackColor = Color.FromArgb(46, 51, 73);

            //load Appointment page
            labelTitle.Text = "Appointment";
            this.panelFormLoader.Controls.Clear();
            frmAppointment formDashboard_Vr6 = new frmAppointment()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }
        private void btnShop_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnShop.Height;
            pnlNav.Top = btnShop.Top;
            pnlNav.Left = btnShop.Left;
            //change button color when clicked
            btnShop.BackColor = Color.FromArgb(46, 51, 73);

            //load Dashboard page
            labelTitle.Text = "Mini Shop";
            this.panelFormLoader.Controls.Clear();
            frmMiniShop formDashboard_Vr6 = new frmMiniShop()
            {
                Dock = DockStyle.Fill,
                TopLevel = false,
                TopMost = true
            };
            formDashboard_Vr6.FormBorderStyle = FormBorderStyle.None;
            this.panelFormLoader.Controls.Add(formDashboard_Vr6);
            formDashboard_Vr6.Show();
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            /*adjust panelNav position according to which nav button clicked*/
            pnlNav.Height = btnSettings.Height;
            pnlNav.Top = btnSettings.Top;
            pnlNav.Left = btnSettings.Left;
            //change button color when clicked
            btnSettings.BackColor = Color.FromArgb(46, 51, 73);
        }

        private void btnDashboard_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnDashboard.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnExercise_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnExercise.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnJournal_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnJournal.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnCalendar_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnJournal.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnAppointment_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnAppointment.BackColor = Color.FromArgb(24, 30, 54);
        }
        private void btnShop_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnShop.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void btnSettings_Leave(object sender, EventArgs e)
        {
            // when mouse leave this button, its color changed back to original
            btnSettings.BackColor = Color.FromArgb(24, 30, 54);
        }

        private void circularProgressBarCal_Click(object sender, EventArgs e)
        {

        }

        private void circularProgressBarSteps_Click(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlSteps_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlWater_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pnlCal_Paint(object sender, PaintEventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
